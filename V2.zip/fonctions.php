<?php

require("connect.php");

function topHashtag($connexion){
	$resultat = mysqli_query($connexion, "SELECT hashtag, COUNT(cm) AS COUNT_CM FROM hashtag_message, hashtag WHERE hashtag.ch = hashtag_message.ch
	GROUP BY hashtag ORDER BY COUNT_CM DESC LIMIT 3");
			
			if ($resultat){
			while($emp = mysqli_fetch_array($resultat)){
				echo $emp["hashtag"] . " : " . $emp["COUNT_CM"] . "</br>";
				}
			}
}

function dernierMessage($connexion, $id){
	
		mysqli_query($connexion, "SET NAMES 'utf8'");
		$rq = 	"SELECT DISTINCT texte, datem FROM message
				WHERE message.auteur IN (SELECT csuivi FROM suivre WHERE csuiveur = " . $id .")
				ORDER BY message.datem DESC
				LIMIT 1"	;
				
		$resultat = mysqli_query($connexion, $rq);
		
		$emp = mysqli_fetch_array($resultat);
		echo '"' . $emp["texte"] . '"' . "</br>";
		
		$rq2 = "SELECT nom,image FROM utilisateur
				WHERE cu = (SELECT auteur FROM message
				WHERE texte =" . '"' . $emp["texte"] . '"' . ")";
		
		$resultat = mysqli_query($connexion, $rq2);
		
		//if(!$resultat){echo "<em>Message de mySQL: </em>".mysqli_error($connexion);}
		
		$datem = explode(" " , $emp["datem"]);
		
		$emp2 = mysqli_fetch_array($resultat);
		echo $emp2["nom"] . ", le " . $datem[0] . " à " . $datem[1] . "</br>";
		echo "<img src = '".$emp2["image"] . "' height='352' width='470'   alt = 'la'>";

}

function derniersUtilisateurs($connexion){
	$resultat = mysqli_query($connexion, 	"SELECT nom, datei FROM `utilisateur`
											ORDER BY datei DESC
											LIMIT 0,3");
		
	if ($resultat){
			while($emp = mysqli_fetch_array($resultat)){
				$datem = explode(" " , $emp["datei"]);
				echo $emp["nom"] . " : le " . $datem[0] . " à " . $datem[1] . "</br>";
			}
	}
	else {
			echo "<em>Message de mySQL: </em>".mysqli_error($connexion);
	};	
}



function partagerMessage($connexion, $id , $message){
	//log = chiffre correspondant à l'utilisateur. Dans un premier temps, c'est Homer
	//Donc log = 1
	
	//Partie message
	$date = date("Y-m-d H:i:s");
	$rq1 = "SELECT COUNT(*) FROM message";

	$requete = mysqli_query($connexion, $rq1);
	
	while($emp = mysqli_fetch_array($requete)){
		
		$rq2 = "INSERT INTO message VALUES (" . ($emp["COUNT(*)"]+1) . " ,  " . '"' . $message . '"' . " , " . $id ." , " . '"' . $date . '"' . ")";
		mysqli_query($connexion, "SET NAMES 'utf8'");
		
		if (strlen($message) == "0"){
			echo "Ton message est vide.</br>";
			break;
		}
		
		$requete2 = mysqli_query($connexion, $rq2);
		
		if (!$requete2){
			echo "<em>Message de mySQL: </em>".mysqli_error($connexion);
			echo "</br> $rq2 "; }
		else {
			echo "Ton message a bien été partagé.</br>";
		}
		
		//Partie hashtag
		$hashtags = explode(" #", $message);
		
		for ($i = 0 ; $i < sizeof($hashtags) ; $i ++){
			if($i >= 1){
				// est ce que le hashtag existe
				$rqhtg1 = "SELECT COUNT(*) FROM hashtag WHERE hashtag = " . '"' ."#" . $hashtags[$i] . '"';
				$requeteHashtag1 = mysqli_query($connexion, $rqhtg1);
				$resc = mysqli_fetch_array($requeteHashtag1);

				
				//si le hashtag existe
				if ($resc["COUNT(*)"] == "1"){
				//on recupere le numero du hashtag et le numero du message
				//ch
				$rqht = "SELECT ch FROM hashtag WHERE hashtag = " . '"' . "#" . $hashtags[$i] . '"';
				$ch = mysqli_query($connexion, $rqht);
				$res2 = mysqli_fetch_array($ch);
				
				//on insere tout cela dans la table hashtag_message
				$rqhtg2 = "INSERT INTO hashtag_message VALUES(" . $res2["ch"] . "," . ($emp["COUNT(*)"]+1) . ")";
				$insert = mysqli_query($connexion, $rqhtg2);
				}
				
				//si le hashtag n'existe pas
				else{
				//on crée un nouveau hashtag dans la base
				$nbH = "SELECT COUNT(*) FROM hashtag";
				$requ = mysqli_query($connexion, $nbH);
				$nbHArray = mysqli_fetch_array($requ);
				//echo $nbHArray["COUNT(*)"] . "</br>";
				$insert1 = "INSERT INTO hashtag VALUES(" . ($nbHArray["COUNT(*)"]+1) . "," . '"' . "#" . $hashtags[$i] . '"' . ")";
				$insert1v2 = mysqli_query($connexion, $insert1);
			
				//on associe le hashtag avec son message (message_hashtag) : à corriger ci dessous
				$rqhtg2 = "INSERT INTO hashtag_message VALUES(" . ($nbHArray["COUNT(*)"]+1) . "," . ($emp["COUNT(*)"]+1) . ")";
				$insert = mysqli_query($connexion, $rqhtg2);
				}
			}
		}	
	}
}	
	
	

function afficheMur($connexion, $id){

	mysqli_query($connexion, "SET NAMES 'utf8'");
	$resultat = mysqli_query($connexion, 	"SELECT DISTINCT texte, datem, auteur FROM message, suivre 
											WHERE auteur = ".$id."
											UNION
											SELECT DISTINCT texte, datem, auteur FROM message, suivre 
											WHERE auteur IN 
											(SELECT DISTINCT csuivi FROM suivre WHERE csuiveur = ".$id.") ORDER BY datem DESC");
	
	if ($resultat){
		while($emp = mysqli_fetch_array($resultat)){
				$datem = explode(" " , $emp["datem"]);
				echo $emp["texte"] . "</br>";
				echo $emp["datem"] . "</br>";
				
				if($emp["auteur"] == $id){echo "Vous avez partagé ce message, le " . $datem[0] . " à " . $datem[1] . "</br></br>";}
				
				else {	$auteur = "SELECT DISTINCT nom FROM utilisateur,message WHERE cu=" . $emp["auteur"] ;
						$rq = mysqli_query($connexion, $auteur);
						$emp2 = mysqli_fetch_array($rq);
						echo $emp2["nom"] . ", le " . $datem[0] . " à " . $datem[1] . "</br></br>";};
			}
	}
	else {
			echo "<em>Message de mySQL: </em>".mysqli_error($connexion);
	};
}

function afficheUtilisateur($connexion, $id, $nom, $suivi, $ville, $description){
	error_reporting(E_ALL ^ E_NOTICE);
	
	$suiviVerif = TRUE;
	
	//echo $suiviVerif."</br>";
	
	$rq = "SELECT DISTINCT * FROM utilisateur";
	
	if ($suivi == "Suivi"){
		$rq .=	",suivre
				WHERE nom LIKE " . '"' . "%" . $nom . "%" . '"' . 
				" AND description LIKE " . '"' . "%" . $description . "%" . '"' . 
				" AND cu = csuivi AND csuiveur = " . $id ;
	}
	
	else{
		
		if ($suivi == "Non suivi") {
			$suiviVerif = FALSE;
			$rq .=	" WHERE nom LIKE " . '"' . "%" . $nom . "%" . '"' . 
					" AND description LIKE " . '"' . "%" . $description . "%" . '"' .
					" AND cu NOT IN (	SELECT DISTINCT csuivi FROM suivre
										WHERE csuiveur = 1)
					AND cu <> " . $id ;
		}
		
		else{
			$rq .= 	" WHERE nom LIKE " . '"' . "%" . $nom . "%" . '"' . 
					" AND description LIKE " . '"' . "%" . $description . "%" . '"' . 
					" AND cu <> " . $id;
		}
	}

	if ($ville != "Ville"){
		$rq .= " AND ville LIKE " . '"' ."%" . $ville . "%" . '"';
	}
	
	$resultat = mysqli_query($connexion, $rq);
	$compteur = 1;
	
	if($resultat){
		echo "<table border='4' cellspacing='10' cellpadding='10'>";
		
		echo "<tr><td><B>NOM</B></td>";
		echo "<td><B>VILLE</B></td>";
		echo "<td><B>DESCRIPTION</B></td>";
		echo "<td><B>PHOTO</B></td>";
		echo "<td><B>MESSAGES</B></td>";
		echo "<td><B>SUIVI</B></td></tr>";
		
		while($emp = mysqli_fetch_array($resultat)){
			echo "<tr><td>" . $emp["nom"] . "</td>";
			echo "<td>" . $emp["ville"] . "</td>";
			echo "<td>" . $emp["description"] . "</td>";
			
			if($emp["image"]){
				echo "<td><img src =" . '"' . $emp["image"] . '"' . " height='152' width='270'></td>";
			}
			else{
				echo "<td><img src = img/profile/NA.jpg height='152' width='270'></td>";
			}
			
			mysqli_query($connexion, "SET NAMES 'utf8'");
			$req2 = "SELECT texte FROM message WHERE auteur =" . $emp["cu"] . " ORDER by datem DESC LIMIT 2";
			$resultat2 = mysqli_query($connexion, $req2);
			
			$text = "";
			
			while($emp2 = mysqli_fetch_array($resultat2)){
				$text .= $emp2["texte"] . "</br></br>";
			}
			echo "<td>" . $text . "</td>";
			
			//partie suivi
			
			$rqf1 = $rq . " LIMIT " . ($compteur-1) . ",1";
			$resultatf1 = mysqli_query($connexion, $rqf1);
			while($emp5 = mysqli_fetch_array($resultatf1)){
				
				$rqf2 = "SELECT COUNT(*) FROM suivre WHERE csuivi =" . $emp5["cu"] . " AND csuiveur =" . $id;
				$resultatf2 = mysqli_query($connexion, $rqf2);
			
				
				if($suiviVerif){
					while($emp6 = mysqli_fetch_array($resultatf2)){
						if($emp6["COUNT(*)"] == 1){
							echo "<form action=" . '"' . "afficheUtilisateur.php" . '"' . " method=" . '"' . "post" . '"' . ">
									<td><input type=" . '"' . "submit" . '"' . "name=" . '"' . "SUIVI" . $compteur . '"' . " value=" . '"' . "UNFOLLOW" . '"' . "></td>
									</form>";
						}
						else{
							echo 	"<form action=" . '"' . "afficheUtilisateur.php" . '"' . " method=" . '"' . "post" . '"' . ">
									<td><input type=" . '"' . "submit" . '"' . "name=" . '"' . "NON_SUIVI" . $compteur . '"' . " value=" . '"' . "FOLLOW" . '"' . "></td>
									</form>";
						}
						
					}
						
				}
				else{
					echo "<form action=" . '"' . "afficheUtilisateur.php" . '"' . " method=" . '"' . "post" . '"' . ">
						<td><input type=" . '"' . "submit" . '"' . "name=" . '"' . "NON_SUIVI" . $compteur . '"' . " value=" . '"' . "FOLLOW" . '"' . "></td>
						</form>";
				}
				
			}
			
			$compteur++;
		}
		
		for ($i = 1 ; $i<$compteur ; $i++){
			
			$rqf1 = $rq . " LIMIT " . ($i-1) . ",1";
			$resultatf1 = mysqli_query($connexion, $rqf1);
			$emp5 = mysqli_fetch_array($resultatf1);
			
			if($_POST["SUIVI".$i]){
				$rqf = "DELETE FROM suivre WHERE csuivi = " . $emp5["cu"] . " AND csuiveur =" . $id;
				$resultatf = mysqli_query($connexion, $rqf);
				header("Refresh:0");
			}
			
			if($_POST["NON_SUIVI".$i]){
				$rqff = "INSERT INTO suivre VALUES(" . $id . "," . $emp5["cu"] . ")";
				$resultatf = mysqli_query($connexion, $rqff);
				header("Refresh:0");
			}
		}
		
		echo "</tr></table>";
	}
	
	else{
		echo "Pas de résultat...</br>";
	}

}

function afficheMessage($connexion, $id, $nom, $ville, $hashtag, $mot_hist){
	mysqli_query($connexion, "SET NAMES 'utf8'");
	
	$compteur = 1 ;
		
	$rq  = 	"SELECT cu FROM utilisateur WHERE ville LIKE " . '"' . "%" . $ville . "%" . '"' . 
			" AND nom LIKE " . '"' . "%" . $nom . "%" . '"';
			
	$rq1 = 	"SELECT cm, texte, datem, auteur FROM message WHERE texte LIKE " . '"' . "%" . $mot_hist . "%" . '"' .
			" AND texte LIKE " . '"' . "%" . $hashtag . "%" . '"' .
			" AND auteur IN (" . $rq . ") ORDER BY datem DESC";
	
	$resultat = mysqli_query($connexion, $rq1);
	
	echo "<table border='4' cellspacing='10' cellpadding='10'>";
		
	echo "<tr><td><B>DATE</B></td>";
	echo "<td><B>MESSAGE</B></td>";
	echo "<td><B>AUTEUR</B></td>";
	echo "<td><B>PHOTO</B></td>";
	echo "<td><B>LIKE</B></tr>";
	
	while($emp=mysqli_fetch_array($resultat)){
		
		echo "<td>" . $emp["datem"] . "</td>";
		echo "<td>" . $emp["texte"] . "</td>";
		
		$rq2 = "SELECT nom, image FROM utilisateur WHERE cu = " . $emp["auteur"];
		$resultat2 = mysqli_query($connexion,$rq2);
		
		while($emp2=mysqli_fetch_array($resultat2)){
			echo "<td>" . $emp2["nom"] . "</td>";
			
			if (!$emp2["image"]){
				echo "<td><img src = img/profile/NA.jpg height='152' width='270'></td>";}
			else{
				echo "<td><img src =" . '"' . $emp2["image"] . '"' . "height='152' width='270'></td>";}
			}
		
		$rq3 = "SELECT DISTINCT COUNT(*), cm, cu FROM aime_message WHERE cu =" . $id . " AND cm =" . $emp["cm"];

		$resultat3 = mysqli_query($connexion, $rq3);
		
		while($emp3=mysqli_fetch_array($resultat3)){
			
			if($emp3["COUNT(*)"] == "1"){
				echo "<td>Vous aimez.</td>";
				$compteur++;
			}

			else{
				echo "<form action=" . '"' . "afficheMessage.php" . '"' . " method=" . '"' . "post" . '"' . ">
				<td><input type=" . '"' . "submit" . '"' . "name=" . '"' . "AIMER" . $compteur . '"' . " value=" . '"' . "AIMER" . '"' . "></td>
				</form>";
				
				$compteur++;
			}
			
		}						
		echo "</tr>";

	}
	
	for ($i = 1 ; $i<$compteur ; $i++){

		if($_POST["AIMER".$i]){

			$rqf1 = $rq1 . " LIMIT " . ($i-1) . ",1";
			$resultatf1 = mysqli_query($connexion, $rqf1);
			$emp5 = mysqli_fetch_array($resultatf1);
			$rqf = "INSERT INTO aime_message VALUES(" . $emp5["cm"] . "," . $id . ")";
			$resultatf = mysqli_query($connexion, $rqf);
			header("Refresh:0");
		}
	}
	
	echo "</table>";

}


function connexion($connexion, $username, $password){
	//echo "</br></br>" . $username." " . $password . "</br>";
	
	$rq = "SELECT COUNT(*), cu FROM utilisateur WHERE nom =".'"'.$username.'"'." AND pwd =".'"'.$password.'"';
	$resultat = mysqli_query($connexion, $rq);
	$emp = mysqli_fetch_array($resultat);
	
	
	//echo $rq."</br>";
	
	if($emp["COUNT(*)"] == 1){
		echo "Vous êtes connectés.</br>";
		return 'profil='.$emp["cu"];
	}
	
	else{
		echo 
		"	<form method=".'"'."get".'"'." action=".'"'."login2.php".'"'." >
			<label for=".'"'."NomUtilisateur".'"'.">Nom Utilisateur :</label>
			<input type=".'"'."text".'"'." id=".'"'."NomUtilisateur".'"'." name=".'"'."NomUtilisateur".'"'." required/>
			<label for=".'"'."mdp".'"'.">Mot de passe :</label>
			<input type=".'"'."password".'"'." id=".'"'."mdp".'"'." name=".'"'."mdp".'"'." required/>
			<input type=".'"'."submit".'"'." value=".'"'."Connexion".'"'."/>";
			
		echo "</br></br>Nom d'utilisateur ou mot de passe incorrect</br>";
		return 'profil=1';
	}
	
	
	
	
	
	
	//return ...;
	
	
	
	
	
}

?>