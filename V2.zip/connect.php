
<?php
	define('NOM', "root");
	define('PASSE', "");
	define('SERVEUR', "localhost");
	define('BASE', "bdc");
	
	$connexion = mysqli_connect("p:".SERVEUR,NOM,PASSE,BASE);
	if (!$connexion){
		echo "Désolé, connexion à ".SERVEUR." ou à la base ".BASE." impossible : ".mysqli_error()."\n";
		exit;
	}
?>