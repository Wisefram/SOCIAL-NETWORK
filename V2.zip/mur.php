<!DOCTYPE html>

<?php  require ("fonctions.php");?>
<html lang="en" dir="ltr">
<head>
<title>Projet</title>
<meta charset="UTF-8">
<link rel="stylesheet" href="styles/layout.css" type="text/css">
</head>
<body>
<div class="wrapper row1">
  <header id="header" class="clear">
    <div id="hgroup">
      <h1><a href="accueil.php">Brèves de couloirs</a></h1>
      <h2>Projet de BD Web 2018-2019</h2>
    </div>
    <nav>
      <ul>
        <li><a href="accueil.php">Accueil</a></li>
        <li><a href="mur.php">Mur</a></li>
        <li><a href="rechercheUtilisateur.php">Recherche utilisateur</a></li>
		<li><a href="rechercheMessage.php">Recherche Message</a></li>
        <li><a href="profil.php">Profil</a></li>
        <li class="last"><a href="login.php">Login</a></li>
      </ul>
    </nav>
  </header>
</div>
<!-- content -->
<div class="wrapper row2">
  <div id="container" class="clear">
    <fieldset>
		<legend>Ajouter un message</legend>
		<section>
			<form method="post" action="validationMessage.php" >
			<article>
				<ul>
					<input type="text" name="message" style="width: 577px" maxlength="140" />
					<input type="submit" value="Envoyer">
				</ul>
			</article>
			</form>
		<section>
	</fieldset>

   
      <article>
        <h2></br>Mes messages</h2>
		<!--img src = "images/bart.jpg" height="352" width="470"   alt = "la" -->
		<p>
		<?php afficheMur($connexion, 1); ?>
		</p>    
      </article>
    
  </div>
</div>
<!-- footer -->
<div class="wrapper row3">
  <footer id="footer" class="clear">
    <p class="fl_left">Travail réalisé par Jean Morales et Paul Salvagniac</p>
    <p class="fl_right">Code by <a href="https://www.os-templates.com/" title="Free Website Templates">OS Templates</a></p>
  </footer>
</div>
</body>
</html>

